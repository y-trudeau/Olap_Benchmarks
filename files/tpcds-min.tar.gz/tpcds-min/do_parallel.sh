SCALE=$1
PARALLEL=$2
OUTDIR=$3
( stdbuf -oL -eL inotifywait -m -e close_write  -r "$3" | stdbuf -oL -eL egrep -v 'ISDIR|zst' | stdbuf -oL -eL cut -d' ' -f3 | stdbuf -oL -eL  xargs -I {} zstd -q -T4 --rm "$3"/{} ) &
pidcompress=$!
for c in $(seq 1 $PARALLEL); do
	(./dsdgen -sc $SCALE -PARALLEL $PARALLEL -CHILD $c -DIR $OUTDIR ) &
done
while [ "$(ls $3 | egrep -c '^web_site.*dat.zst$')" -ne 1 ]; do sleep 2; done
pkill -P $pidcompress
pkill $pidcompress
